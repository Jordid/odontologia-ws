import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-medics-table-with-menu',
  templateUrl: './medics-table-with-menu.component.html',
  styleUrls: ['./medics-table-with-menu.component.scss']
})
export class MedicsTableWithMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
