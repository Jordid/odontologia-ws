import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-medics',
  templateUrl: './medics.component.html',
  styleUrls: ['./medics.component.scss']
})
export class MedicsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
