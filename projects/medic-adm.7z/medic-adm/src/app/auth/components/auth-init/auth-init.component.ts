import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-auth-init',
  templateUrl: './auth-init.component.html',
  styleUrls: ['./auth-init.component.scss']
})
export class AuthInitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
