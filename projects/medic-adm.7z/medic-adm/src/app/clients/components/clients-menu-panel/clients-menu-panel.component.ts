import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-clients-menu-panel',
  templateUrl: './clients-menu-panel.component.html',
  styleUrls: ['./clients-menu-panel.component.scss']
})
export class ClientsMenuPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
