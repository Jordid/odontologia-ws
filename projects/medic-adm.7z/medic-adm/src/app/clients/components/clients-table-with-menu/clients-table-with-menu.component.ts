import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-clients-table-with-menu',
  templateUrl: './clients-table-with-menu.component.html',
  styleUrls: ['./clients-table-with-menu.component.scss']
})
export class ClientsTableWithMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
