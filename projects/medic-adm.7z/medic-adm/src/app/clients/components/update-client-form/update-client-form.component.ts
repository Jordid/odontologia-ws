import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-update-client-form',
  templateUrl: './update-client-form.component.html',
  styleUrls: ['./update-client-form.component.scss']
})
export class UpdateClientFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
