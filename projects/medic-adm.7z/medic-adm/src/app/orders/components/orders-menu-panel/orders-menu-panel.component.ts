import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-orders-menu-panel',
  templateUrl: './orders-menu-panel.component.html',
  styleUrls: ['./orders-menu-panel.component.scss']
})
export class OrdersMenuPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
