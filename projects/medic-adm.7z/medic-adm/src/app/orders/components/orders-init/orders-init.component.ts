import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-orders-init',
  templateUrl: './orders-init.component.html',
  styleUrls: ['./orders-init.component.scss']
})
export class OrdersInitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
