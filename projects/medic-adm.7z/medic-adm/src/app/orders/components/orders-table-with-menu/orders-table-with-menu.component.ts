import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-orders-table-with-menu',
  templateUrl: './orders-table-with-menu.component.html',
  styleUrls: ['./orders-table-with-menu.component.scss']
})
export class OrdersTableWithMenuComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
