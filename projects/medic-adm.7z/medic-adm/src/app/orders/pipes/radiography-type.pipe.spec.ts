import { RadiographyTypePipe } from './radiography-type.pipe';

describe('RadiographyTypePipe', () => {
  it('create an instance', () => {
    const pipe = new RadiographyTypePipe();
    expect(pipe).toBeTruthy();
  });
});
