export enum ExamCategoryTypeEnum {
  BASIC = 'BASIC',
  WITH_STUDY = 'WITH_STUDY',
  WITH_DENTAL_PIECES = 'WITH_DENTAL_PIECES',
}
