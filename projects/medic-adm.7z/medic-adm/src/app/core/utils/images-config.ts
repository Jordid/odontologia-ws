export const ImagesConfig = {
  medicAvatar: './assets/images/medic_avatar.png',
  userAvatar: './assets/images/medic_avatar.png',
  login_icon: './assets/images/login_icon.png',
};
