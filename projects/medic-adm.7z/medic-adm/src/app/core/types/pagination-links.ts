export interface PaginationLinks {
  total: number;
  first: string;
  last: string;
  prev: string;
  next: string;
}
