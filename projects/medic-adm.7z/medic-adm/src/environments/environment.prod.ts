export const environment = {
  production: true
};

export const appEnvironment = {
  appCode: 'odo-2022-06-09',
};

export const apiRadioGrafEnvironment = {
  baseUrl: 'https://app.rayodent.com/api',
};
