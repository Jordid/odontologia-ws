export interface IUser {
  avatarUrl: string;
  email: string;
  emailVerifiedAt: string;
  name: string;
  userId: number;
}
