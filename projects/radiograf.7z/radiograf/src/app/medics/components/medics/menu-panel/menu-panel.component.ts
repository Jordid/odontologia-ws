import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-menu-panel',
  templateUrl: './menu-panel.component.html',
  styleUrls: ['./menu-panel.component.scss']
})
export class MenuPanelComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
