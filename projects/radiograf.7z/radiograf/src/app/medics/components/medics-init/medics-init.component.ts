import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-medics-init',
  templateUrl: './medics-init.component.html',
  styleUrls: ['./medics-init.component.scss']
})
export class MedicsInitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
