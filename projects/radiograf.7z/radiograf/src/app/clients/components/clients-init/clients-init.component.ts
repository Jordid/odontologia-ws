import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'odo-clients-init',
  templateUrl: './clients-init.component.html',
  styleUrls: ['./clients-init.component.scss']
})
export class ClientsInitComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
