export interface IFile {
  fileUrl: string;
  originalName: string;
  storageId: string;
}
