export interface ISelectedPiece {
  code: string;
  selecetd: boolean;
}
