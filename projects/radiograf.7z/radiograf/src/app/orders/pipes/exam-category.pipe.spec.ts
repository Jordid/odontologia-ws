import { ExamCategoryPipe } from './exam-category.pipe';

describe('ExamCategoryPipe', () => {
  it('create an instance', () => {
    const pipe = new ExamCategoryPipe();
    expect(pipe).toBeTruthy();
  });
});
